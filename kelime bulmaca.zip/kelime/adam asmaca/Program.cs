﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace adam_asmaca
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] kelime = new string[] { "kelebek", "galatasaray", "türkiye", "bilgisayar", "akdeniz"};
            Random random = new Random();
            int sayi = random.Next(0, kelime.Length); 
            string secilenKelime = kelime[sayi];

            Console.Write("Rastgele Seçilen Kelime : ( " + secilenKelime.Length + " ) harflidir.\n");
            string[] yildiz = new string[secilenKelime.Length];
            string harf = " ";
            for (int i = 0; i < secilenKelime.Length; i++)
            {
                yildiz[i] = "*".ToString();
                harf = harf + "*" + " ";

            }
            Console.WriteLine("\n" + harf);

            Console.Write("\n Bir adet harf giriniz : ");  
            string tahmin = Console.ReadLine();
            Console.Clear();

            for (int i = 1; i <= 10; i++)  
            {
                int yildizsayisi = 0;  

                for (int j = 0; j < secilenKelime.Length; j++)
                {
                    if (yildiz[j] == "*")
                    {
                        yildizsayisi++;  
                    }
                }


                for (int k = 0; k < secilenKelime.Length; k++)
                {
                    if (secilenKelime[k].ToString() == tahmin.ToString())
                    {
                        yildiz[k] = tahmin.ToString();  
                        --yildizsayisi; 

                    }


                }
                for (int k = 0; k < secilenKelime.Length; k++)
                {
                    Console.Write(" " + yildiz[k].ToString());
                }

                if (yildizsayisi != 0)  
                {
                    int hak = 10;
                    hak = hak - i;
                    Console.WriteLine("\n" + hak + "  hakkınız kaldı.");
                    
                    Console.WriteLine("\nKalan gizli harf sayisi: " + yildizsayisi);
                    Console.Write("\n Bir adet harf giriniz : ");
                    tahmin = Console.ReadLine();
                    Console.Clear();
                }

                else
                {
                    Console.Clear();
                    Console.Write("Tebrikler kazandın!");
                    Console.ReadLine();
                    return;
                }

            }
            Console.Clear();
            Console.WriteLine("Oynama hakkınız bitmiştir.\nAradığınız kelime: " + secilenKelime.ToUpper() + " idi.");
            Console.ReadLine();
        }
    }
}
